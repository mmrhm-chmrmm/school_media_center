
def site_info(request):
    return {
        'school_name': 'Школа №1539',
        'address': 'ул.Маломосковская д.7',
        'phone': '+7 (499) 299-15-39',
        'email': '1539@edu.mos.ru',
    }
